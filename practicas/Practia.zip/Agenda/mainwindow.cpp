#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    bool agregar, mostrar, limpiar;
    agregar =ui->radioButton->isChecked();
    mostrar =ui->radioButton_2->isChecked();
    limpiar =ui->radioButton_3->isChecked();
    int data= ui->lineEdit->text().toInt();
    if(agregar){
        arreglo.push_back(data);//Coloca numeros en los vectores
        ui->lineEdit->clear();//
    }
    if(mostrar){
        int size=arreglo.size();
        ui->plainTextEdit->clear();
        for(int i=0;i<size;i++){
            ui->plainTextEdit->appendPlainText(QString::number(arreglo[i]));
        }
    }
    if(limpiar){
        arreglo.push_back(data);
        ui->plainTextEdit->clear();
    }
}

