#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<vector>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}



void MainWindow::on_pushButton_2_clicked()
{

    QString Nombres=ui->lineEdit->text();
    double pesos=ui->lineEdit_3->text().toDouble();
    int Edades=ui->lineEdit_2->text().toInt();
    Personas->push_back({Nombres,Edades,pesos});
    ui->lineEdit->clear();
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();

}


void MainWindow::on_pushButton_clicked()
{
        int size1=Personas->size();
        ui->plainTextEdit->clear();
        for(int i=0; i<size1;i++){
            ui->plainTextEdit->appendPlainText(Personas->at(i).name);
            ui->plainTextEdit->appendPlainText(QString::number(Personas->at(i).edad));
            ui->plainTextEdit->appendPlainText(QString::number(Personas->at(i).peso));
        }
}


void MainWindow::on_pushButton_3_clicked()
{
    ui->plainTextEdit->clear();
}



